const optionsPanel = document.querySelector("#options-panel");


// Call when selection changed or should change visibility for example due to mode edit
// TODO call this when selection changed
function updateOptionsPanel(visible) {
    optionsPanel.style.display = visible ? "flex" : "none";
}
